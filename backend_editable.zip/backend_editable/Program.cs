using edutrack_academy_api.Data;
using edutrack_academy_api.Hubs;
using edutrack_academy_api.JWT;
using edutrack_academy_api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Linq;
using System.Text;

var seedOnlyFlag = "--seed-demo";
// Permite ejecutar `dotnet run -- --seed-demo` para poblar datos sin montar la API completa.
var seedOnly = args.Any(a => a.Equals(seedOnlyFlag, StringComparison.OrdinalIgnoreCase));
var filteredArgs = args.Where(a => !a.Equals(seedOnlyFlag, StringComparison.OrdinalIgnoreCase)).ToArray();

var builder = WebApplication.CreateBuilder(filteredArgs);

// Bootstrap central: configura EF, autenticación JWT, SignalR y seeding opcional.

// Add services to the container.

// DbContext que expone las entidades académicas principales.
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("AcademiaConnection")));

// Servicios de dominio inyectados en controladores y hubs.
builder.Services.AddScoped<IUsuarioService, UsuarioService>();
builder.Services.AddScoped<IGrupoSyncService, GrupoSyncService>();
builder.Services.AddScoped<IPortalCredentialService, PortalCredentialService>();
builder.Services.AddScoped<DemoDataSeeder>();
builder.Services.AddScoped<JwtTokenGenerator>();
builder.Services.AddSingleton<INotificationDispatcher, NotificationDispatcher>();

builder.Services.AddSignalR();

builder.Services.AddControllers();

// JWT Auth
var key = Encoding.UTF8.GetBytes(builder.Configuration["JwtSettings:Key"]!);

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ValidateLifetime = true
        };

        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {
                var accessToken = context.Request.Query["access_token"];
                var path = context.HttpContext.Request.Path;

                if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hubs/notifications"))
                {
                    context.Token = accessToken;
                }

                return Task.CompletedTask;
            }
        };
    });
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Middlewares base + Swagger solo para entornos de desarrollo.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHub<NotificationHub>("/hubs/notifications");

using (var scope = app.Services.CreateScope())
{
    if (seedOnly)
    {
        // Modo semilla: carga datos demo y termina sin levantar el web host.
        var seeder = scope.ServiceProvider.GetRequiredService<DemoDataSeeder>();
        seeder.SeedAsync(force: true).GetAwaiter().GetResult();
        return;
    }

    // Sincroniza cursos automáticamente para que cada grado tenga sus grupos configurados al arranque.
    var syncService = scope.ServiceProvider.GetRequiredService<IGrupoSyncService>();
    syncService.EnsureCursosForAllGradosAsync().GetAwaiter().GetResult();
}

app.Run();
