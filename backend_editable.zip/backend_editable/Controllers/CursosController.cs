﻿using edutrack_academy_api.Data;
using edutrack_academy_api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace edutrack_academy_api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "admin,docente")]
    public class CursosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CursosController(AppDbContext context)
        {
            _context = context;
        }

        // Listado básico de cursos con docente y grado para llenar tablas del panel.
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetCursos()
        {
            var cursos = await _context.Cursos
                .Include(c => c.Docente)
                .Include(c => c.Grado)
                .Select(c => new
                {
                    c.Id,
                    c.Nombre,
                    c.Grupo,
                    GradoId = c.GradoId,
                    GradoNombre = c.Grado != null ? c.Grado.Nombre : null,
                    GradoCodigo = c.Grado != null ? c.Grado.Codigo : null,
                    DocenteId = c.DocenteId,
                    DocenteNombre = c.Docente != null ? c.Docente.Nombre : null
                })
                .ToListAsync();

            return Ok(cursos);
        }

        // Crea un curso nuevo (solo admins) y devuelve los datos principales.
        [HttpPost]
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> CrearCurso(CursoDTO dto)
        {
            var curso = new Curso
            {
                Nombre = dto.Nombre,
                GradoId = dto.GradoId,
                Grupo = dto.Grupo ?? string.Empty,
                DocenteId = dto.DocenteId
            };

            _context.Cursos.Add(curso);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                curso.Id,
                curso.Nombre,
                curso.Grupo,
                GradoId = curso.GradoId,
                curso.DocenteId
            });
        }

        // Actualiza nombre, grado, grupo y docente del curso indicado.
        [HttpPut("{id:int}")]
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> ActualizarCurso(int id, CursoDTO dto)
        {
            var curso = await _context.Cursos.FindAsync(id);
            if (curso == null)
                return NotFound("Curso no encontrado");

            curso.Nombre = dto.Nombre;
            curso.GradoId = dto.GradoId;
            curso.Grupo = dto.Grupo ?? string.Empty;
            curso.DocenteId = dto.DocenteId;

            await _context.SaveChangesAsync();
            return Ok(new
            {
                curso.Id,
                curso.Nombre,
                GradoId = curso.GradoId,
                curso.DocenteId
            });
        }

        // Elimina por completo el curso y sus vínculos de inscripción.
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> EliminarCurso(int id)
        {
            var curso = await _context.Cursos.FindAsync(id);
            if (curso == null)
                return NotFound("Curso no encontrado");

            _context.Cursos.Remove(curso);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Devuelve los estudiantes inscritos para poblar listados en frontend.
        [HttpGet("{id:int}/students")]
        public async Task<IActionResult> GetEstudiantesCurso(int id)
        {
            var estudiantes = await _context.Inscripciones
                .Where(i => i.CursoId == id)
                .Include(i => i.Estudiante)
                .Select(i => new { i.Estudiante!.Id, i.Estudiante!.Nombre, i.Estudiante!.Documento })
                .ToListAsync();

            return Ok(estudiantes);
        }
    }
}
